#!/usr/bin/env bash
# TP8 商城演示全流程基线：固定顺序请求，输出拼成一份对照文本
set -u
BASE=${1:-http://127.0.0.1:8090}
TS=$(date +%s)
OUT=${2:-/tmp/tp8_baseline.txt}
: > "$OUT"

req() { # method url [curl args...]
    local m=$1 u=$2; shift 2
    echo "== $m $u ==" >> "$OUT"
    if [ "$m" = GET ]; then
        curl -s "$BASE$u" "$@" >> "$OUT" 2>&1
    else
        curl -s -X "$m" "$BASE$u" "$@" >> "$OUT" 2>&1
    fi
    echo >> "$OUT"
}

req GET /shop/seed
req GET /shop/products
req POST /shop/place -H 'Content-Type: application/json' -H "x-sign: t" -H "x-ts: $TS" -d '{"user_id":1,"items":[{"product_id":1,"qty":2},{"product_id":2,"qty":1}]}'
req POST /shop/place -H 'Content-Type: application/json' -H "x-sign: t" -H "x-ts: $TS" -d '{"user_id":2,"items":[{"product_id":1,"qty":999}]}'
req POST /shop/place -H 'Content-Type: application/json' -H "x-sign: t" -H "x-ts: $TS" -d '{"user_id":9,"items":[{"product_id":1,"qty":1}]}'
req POST /shop/place -H 'Content-Type: application/json' -d '{"user_id":1,"items":[{"product_id":1,"qty":1}]}'
req POST /shop/place -H 'Content-Type: application/json' -H "x-sign: t" -H "x-ts: $TS" -d '{"user_id":1,"items":[]}'
req GET /shop/dashboard
req GET /shop/order/1
req GET /shop/order/999
req GET "/shop/calc?base=100&qty=5"
req GET "/shop/search?kw=%E9%94%AE"
req GET /shop/review-stats
req GET /shop/review-stats

echo "baseline saved to $OUT ($(wc -l < "$OUT") lines)"
