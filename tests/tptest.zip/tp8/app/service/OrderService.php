<?php
declare(strict_types=1);

namespace app\service;

use app\model\Order;
use app\model\OrderItem;
use app\model\Product;
use app\model\User;
use think\facade\Db;

/**
 * 订单服务：事务、锁、复杂业务编排
 */
class OrderService
{
    /**
     * 下单：事务 + 行锁 + 库存扣减 + 金额分摊
     * @param int   $userId
     * @param array $items [['product_id'=>1,'qty'=>2], ...]
     * @return array{order_id:int,total:float}
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\Exception
     */
    public function placeOrder(int $userId, array $items): array
    {
        if (empty($items)) {
            throw new \think\Exception('订单项不能为空');
        }

        return Db::transaction(function () use ($userId, $items) {
            // 锁用户
            $user = User::where('id', $userId)->lock(true)->find();
            if (!$user) {
                throw new \think\Exception('用户不存在');
            }

            $total = 0.0;
            $lines = [];
            foreach ($items as $it) {
                $pid = (int)($it['product_id'] ?? 0);
                $qty = (int)($it['qty'] ?? 0);
                if ($pid <= 0 || $qty <= 0) {
                    throw new \think\Exception('非法订单项');
                }
                // 行锁读取商品
                $p = Product::where('id', $pid)->lock(true)->find();
                if (!$p || !$p->on_sale) {
                    throw new \think\Exception("商品 {$pid} 不在售");
                }
                if ($p->stock < $qty) {
                    throw new \think\Exception("商品 {$pid} 库存不足");
                }
                $lineTotal = round($p->final_price * $qty, 2);
                $total = round($total + $lineTotal, 2);
                $lines[] = [
                    'product_id' => $pid,
                    'qty'        => $qty,
                    'unit_price' => $p->final_price,
                    'line_total' => $lineTotal,
                ];
                // 直接扣库存（已持行锁）
                Db::name('products')->where('id', $pid)->dec('stock', $qty)->update();
            }

            // 满减优惠
            $total = $this->applyPromotion($total, $user->vip_level);

            $order = Order::create([
                'user_id' => $userId,
                'total'   => $total,
                'status'  => Order::STATUS_PENDING,
            ]);
            foreach ($lines as $line) {
                OrderItem::create($line + ['order_id' => $order->id]);
            }
            return ['order_id' => (int)$order->id, 'total' => $total];
        });
    }

    /**
     * 满减：VIP 等级折扣叠加满减门槛
     */
    public function applyPromotion(float $total, int $vipLevel): float
    {
        $rate = match (true) {
            $vipLevel >= 5 => 0.85,
            $vipLevel >= 3 => 0.92,
            $vipLevel >= 1 => 0.97,
            default        => 1.0,
        };
        $total = round($total * $rate, 2);
        if ($total >= 1000.0) {
            $total = round($total - 100.0, 2);   // 满 1000 减 100
        } elseif ($total >= 500.0) {
            $total = round($total - 30.0, 2);    // 满 500 减 30
        }
        return $total;
    }

    /**
     * 支付回调：幂等更新状态
     */
    public function markPaid(int $orderId): bool
    {
        $affected = Order::where('id', $orderId)
            ->where('status', Order::STATUS_PENDING)
            ->update(['status' => Order::STATUS_PAID]);
        return $affected > 0;
    }
}
