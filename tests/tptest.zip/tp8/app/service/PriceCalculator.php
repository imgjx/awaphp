<?php
declare(strict_types=1);

namespace app\service;

/**
 * 价格计算：演示静态工具类 + 递归 + 引用传参 + 生成器等
 */
class PriceCalculator
{
    /** 阶梯批发价（递归实现 + 尾递归记忆化数组） */
    public static function tierPrice(float $base, int $qty, array $memo = []): float
    {
        if ($qty <= 0) {
            return 0.0;
        }
        if ($qty === 1) {
            return $base;
        }
        if (isset($memo[$qty])) {
            return $memo[$qty];
        }
        $step = $qty % 2 === 0 ? $qty / 2 : $qty - 1;
        $r = round(self::tierPrice($base, $step, $memo) + ($qty - $step) * $base * 0.9, 4);
        $memo[$qty] = $r;
        return $r;
    }

    /** 多币种换算：match + nullsafe + 解构 */
    public static function convert(float $amount, string $from = 'CNY', ?string $to = null): float
    {
        $rates = [
            'CNY' => 1.0,
            'USD' => 0.14,
            'EUR' => 0.13,
            'JPY' => 21.0,
        ];
        $to ??= 'CNY';
        $r = $rates[$from] ?? throw new \InvalidArgumentException("未知币种 {$from}");
        $t = $rates[$to] ?? throw new \InvalidArgumentException("未知币种 {$to}");
        return round($amount / $r * $t, 4);
    }

    /** 引用传参：就地排序 + 去重 */
    public static function sortDedup(array &$arr): int
    {
        sort($arr);
        $arr = array_values(array_unique($arr));
        return count($arr);
    }

    /** 生成器：产出价格区间分桶 */
    public static function bucketize(array $prices, float $step): \Generator
    {
        $bucket = [];
        $cur = 0.0;
        foreach ($prices as $p) {
            while ($p >= $cur + $step) {
                yield $cur => $bucket;
                $cur += $step;
                $bucket = [];
            }
            $bucket[] = $p;
        }
        if ($bucket) {
            yield $cur => $bucket;
        }
    }

    /** heredoc 模板渲染 */
    public static function renderReceipt(string $name, float $total): string
    {
        return <<<EOT
--- 收据 ---
客户: {$name}
应付: {$total} 元
EOT;
    }
}
