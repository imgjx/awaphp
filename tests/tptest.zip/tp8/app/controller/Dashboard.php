<?php
declare(strict_types=1);

namespace app\controller;

/**
 * 极复杂 PHP/HTML 混写页面控制器（高级混写 / TP8 端到端验证用）。
 *
 * 数据经 $GLOBALS['__awa_dashboard'] 传给模板：跨文件只耦合字符串键，
 * 因此控制器与模板各自独立混淆（变量重命名）也不会失配。
 * 控制器自身开一层输出缓冲 include 原生 PHP 模板，返回字符串作为响应体。
 */
class Dashboard
{
    public function index()
    {
        $GLOBALS['__awa_dashboard'] = [
            'title'  => 'AWA 商城 · TP8 实时看板',
            'badge'  => 'TP8',
            'nav'    => [
                ['k' => 'overview', 'label' => '概览', 'on' => true],
                ['k' => 'goods',    'label' => '商品', 'on' => false],
                ['k' => 'orders',   'label' => '订单', 'on' => true],
                ['k' => 'matrix',   'label' => '矩阵', 'on' => false],
            ],
            'products' => [
                ['id' => 1, 'name' => '机械键盘', 'price' => 399.0,  'stock' => 50, 'on_sale' => 1, 'tags' => ['外设', '键盘']],
                ['id' => 2, 'name' => '显示器',   'price' => 1299.0, 'stock' => 3,  'on_sale' => 1, 'tags' => ['外设', '显示']],
                ['id' => 3, 'name' => '扩展坞',   'price' => 259.0,  'stock' => 0,  'on_sale' => 1, 'tags' => ['配件']],
                ['id' => 4, 'name' => '已下架品', 'price' => 99.0,   'stock' => 99, 'on_sale' => 0, 'tags' => []],
            ],
            'orders' => [
                ['id' => 2001, 'user' => 'awa',   'amount' => 798.0,  'status' => 'paid'],
                ['id' => 2002, 'user' => 'guest', 'amount' => 1299.0, 'status' => 'pending'],
                ['id' => 2003, 'user' => 'awa',   'amount' => 259.0,  'status' => 'closed'],
            ],
            'stats'  => ['total' => 4, 'onSale' => 3, 'lowStock' => 2, 'revenue' => 2356.0],
            'matrix' => [[1, 2, 3, 4], [5, 6, 7, 8]],
            'flags'  => [true, true, false, true],
            'notice' => '数据由 TP8 控制器注入；库存低于 5 已标红',
        ];
        ob_start();
        include __DIR__ . '/../../view/shop_dashboard.php';
        return ob_get_clean();
    }
}
