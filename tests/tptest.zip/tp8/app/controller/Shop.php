<?php
declare(strict_types=1);

namespace app\controller;

use app\middleware\SignAuth;
use app\model\Order;
use app\model\Product;
use app\model\Review;
use app\model\User;
use app\service\OrderService;
use app\service\PriceCalculator;
use app\validate\OrderValidate;
use think\facade\Cache;
use think\facade\Db;
use think\facade\Log;
use think\Request;

/**
 * 商城 API 控制器（复杂逻辑演示：事务/锁/缓存/事件/验证器）
 */
class Shop extends \app\BaseController
{
    public $middleware = [
        SignAuth::class => ['only' => ['place']],
    ];

    /**
     * GET /shop/seed —— 初始化 SQLite 演示数据
     */
    public function seed()
    {
        $this->initSchema();
        Db::execute('DELETE FROM users'); Db::execute('DELETE FROM sqlite_sequence'); Db::execute('DELETE FROM products');
        Db::execute('DELETE FROM orders'); Db::execute('DELETE FROM order_items'); Db::execute('DELETE FROM reviews');
        Db::name('users')->insertAll([
            ['id' => 1, 'username' => 'awa', 'vip_level' => 3],
            ['id' => 2, 'username' => 'guest', 'vip_level' => 0],
        ]);
        Db::name('products')->insertAll([
            ['id' => 1, 'name' => ' 机械键盘 ', 'price' => 399.0, 'stock' => 50, 'discount' => 0.9, 'on_sale' => 1, 'tags' => '["外设","键盘"]', 'attrs' => '{"axis":"red"}'],
            ['id' => 2, 'name' => '显示器', 'price' => 1299.0, 'stock' => 10, 'discount' => 0.95, 'on_sale' => 1, 'tags' => '["外设"]', 'attrs' => '{}'],
            ['id' => 3, 'name' => '已下架品', 'price' => 99.0, 'stock' => 99, 'discount' => 1.0, 'on_sale' => 0, 'tags' => '[]', 'attrs' => '{}'],
        ]);
        return json(['code' => 0, 'msg' => 'ok', 'users' => count(Db::name('users')->select()), 'products' => count(Db::name('products')->select())]);
    }

    /**
     * GET /shop/products —— 商品列表（缓存 + 获取器 + JSON 字段 + 关联统计）
     */
    public function products()
    {
        $this->initSchema();
        $list = Cache::remember('shop:products', function () {
            return Product::order('id', 'asc')
                ->select()
                ->map(function (Product $p) {
                    return [
                        'id'          => $p->id,
                        'name'        => $p->name,
                        'final_price' => $p->final_price,   // 获取器
                        'stock'       => $p->stock,
                        'on_sale'     => $p->on_sale,
                        'tags'        => $p->tags,          // json 字段自动解码
                        'attrs'       => $p->attrs,
                    ];
                })
                ->toArray();
        }, 60);
        return json(['code' => 0, 'data' => $list]);
    }

    /**
     * POST /shop/place —— 下单（验证器 + 事务 + 行锁 + 满减）
     */
    public function place(Request $request)
    {
        $this->initSchema();
        $data = [
            'user_id' => (int)$request->post('user_id', 0),
            'items'   => (array)$request->post('items', []),
        ];
        try {
            validate(OrderValidate::class)->scene('place')->check($data);
        } catch (\think\exception\ValidateException $e) {
            return json(['code' => 422, 'msg' => $e->getError()], 422);
        }
        try {
            $svc = new OrderService();
            $ret = $svc->placeOrder($data['user_id'], $data['items']);
            Cache::delete('shop:products');  // 库存变化失效缓存
            event('OrderPlaced', $ret);
            return json(['code' => 0, 'data' => $ret]);
        } catch (\Throwable $e) {
            Log::warning('place order fail: ' . $e->getMessage());
            return json(['code' => 400, 'msg' => $e->getMessage()], 400);
        }
    }

    /**
     * GET /shop/order/:id —— 订单详情（关联 + 状态机）
     */
    public function order(int $id)
    {
        $this->initSchema();
        $order = Order::with(['user', 'items.product'])->find($id);
        if (!$order) {
            return json(['code' => 404, 'msg' => 'not found'], 404);
        }
        return json([
            'code' => 0,
            'data' => [
                'id'     => $order->id,
                'user'   => $order->user?->username,
                'status' => $order->status_text,
                'total'  => $order->total,
                'items'  => array_map(function ($it) {
                    return [
                        'product' => $it['product']['name'] ?? '?',
                        'qty'     => $it['qty'],
                        'sum'     => $it['line_total'],
                    ];
                }, $order->items->toArray()),
            ],
        ]);
    }

    /**
     * GET /shop/calc —— 演示复杂语法集中地（递归/match/生成器/解构/引用/heredoc/nullsafe）
     */
    public function calc(Request $request)
    {
        $base = (float)$request->get('base', '100');
        $qty  = (int)$request->get('qty', '5');

        $out = [];
        $out['tier'] = PriceCalculator::tierPrice($base, $qty);
        $out['usd']  = PriceCalculator::convert($base, 'CNY', 'USD');

        $arr = [5, 3, 3, 1, 9, 5];
        $n = PriceCalculator::sortDedup($arr);
        $out['dedup'] = [$n, $arr];

        $buckets = [];
        foreach (PriceCalculator::bucketize([12.0, 45.5, 88.0, 120.0], 50.0) as $from => $b) {
            $buckets[] = [$from, count($b)];
        }
        $out['buckets'] = $buckets;

        // 列表解构 + ??=
        ['usd' => $u, 'eur' => $e] = [
            'usd' => PriceCalculator::convert($base, 'CNY', 'USD'),
            'eur' => PriceCalculator::convert($base, 'CNY', 'EUR'),
        ];
        $out['fx'] = [$u, $e];

        // ?? 链 + 空安全
        $order = Order::findOrEmpty(999999);
        $out['nullsafe'] = $order->user?->username ?? '(none)';

        $out['receipt'] = PriceCalculator::renderReceipt('awa', 399.0);

        return json(['code' => 0, 'data' => $out]);
    }

    /**
     * GET /shop/search —— 搜索器 + 作用域
     */
    public function search(Request $request)
    {
        $this->initSchema();
        $kw = (string)$request->get('kw', '');
        $q = (new Product())->withSearch(['name'], ['name' => $kw]);
        $rows = $q->scope('onSale')->select();
        return json(['code' => 0, 'data' => array_column($rows->toArray(), 'name')]);
    }

    /**
     * GET /shop/review-stats —— 聚合查询
     */
    public function reviewStats()
    {
        $this->initSchema();
        Db::name('reviews')->insertAll([
            ['product_id' => 1, 'stars' => 5, 'content' => '好'],
            ['product_id' => 1, 'stars' => 4, 'content' => '不错'],
            ['product_id' => 2, 'stars' => 3, 'content' => '一般'],
        ]);
        $stats = Db::name('reviews')
            ->field('product_id, COUNT(*) AS cnt, ROUND(AVG(stars),2) AS avg_stars')
            ->group('product_id')
            ->select()
            ->toArray();
        return json(['code' => 0, 'data' => $stats]);
    }

    /** 建表（SQLite 内存演示） */
    public function initSchema(): void
    {
        if (Cache::get('shop:schema')) {
            return;
        }
        $sqls = [
            'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, vip_level INTEGER DEFAULT 0, created_at INTEGER, updated_at INTEGER)',
            'CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL, stock INTEGER, discount REAL DEFAULT 1.0, on_sale INTEGER DEFAULT 1, tags TEXT, attrs TEXT, created_at INTEGER, updated_at INTEGER)',
            'CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, total REAL, status INTEGER DEFAULT 0, created_at INTEGER, updated_at INTEGER)',
            'CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, product_id INTEGER, qty INTEGER, unit_price REAL, line_total REAL)',
            'CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, stars INTEGER, content TEXT, created_at INTEGER, updated_at INTEGER)',
        ];
        Db::execute('DROP TABLE IF EXISTS users'); Db::execute('DROP TABLE IF EXISTS products'); Db::execute('DROP TABLE IF EXISTS orders'); Db::execute('DROP TABLE IF EXISTS order_items'); Db::execute('DROP TABLE IF EXISTS reviews');
        foreach ($sqls as $sql) {
            Db::execute($sql);
        }
        Cache::set('shop:schema', 1, 3600);
    }
}
