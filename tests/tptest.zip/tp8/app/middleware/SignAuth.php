<?php
declare(strict_types=1);

namespace app\middleware;

use think\Response;

/**
 * 简易签名校验中间件（演示中间件参数）
 */
class SignAuth
{
    public function handle($request, \Closure $next, string $realm = 'api')
    {
        $sign = $request->header('x-sign', '');
        $ts   = (int)$request->header('x-ts', '0');
        if (!$sign || abs(time() - $ts) > 300) {
            return json(['code' => 401, 'msg' => "signature expired [{$realm}]"], 401);
        }
        return $next($request);
    }
}
