<?php
declare(strict_types=1);

namespace app\validate;

use think\Validate;

class OrderValidate extends Validate
{
    protected $rule = [
        'user_id|用户ID' => 'require|integer|gt:0',
        'items'          => 'require|array|min:1',
    ];

    protected $scene = [
        'place' => ['user_id', 'items'],
    ];
}
