<?php
// 事件定义文件
return [
    'bind'      => [],

    'listen'    => [
        'AppInit'  => [],
        'HttpRun'  => [],
        'HttpEnd'  => [],
        'LogLevel' => [],
        'LogWrite' => [],
        'OrderPlaced' => [app\listener\OrderPlaced::class],
    ],

    'subscribe' => [
    ],
];
