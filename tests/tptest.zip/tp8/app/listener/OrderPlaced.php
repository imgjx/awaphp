<?php
declare(strict_types=1);

namespace app\listener;

use think\facade\Log;

class OrderPlaced
{
    public function handle(array $payload): void
    {
        Log::info("order placed: #{$payload['order_id']} total={$payload['total']}");
    }
}
