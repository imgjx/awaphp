<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\model\User;

/**
 * 多级控制器（admin 应用下）
 */
class Dashboard extends \app\BaseController
{
    public function index()
    {
        $users = User::count();
        return "admin dashboard: {$users} users";
    }
}
