<?php
declare(strict_types=1);

namespace app\model;

use think\Model;

class Review extends Model
{
    protected $table = 'reviews';
    protected $autoWriteTimestamp = true;
}
