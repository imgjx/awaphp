<?php
declare(strict_types=1);

namespace app\model;

use think\Model;
use think\model\relation\HasMany;

/**
 * 商品模型：演示关联、获取器/修改器、搜索器、类型转换
 */
class Product extends Model
{
    protected $table = 'products';

    // 类型转换
    protected $type = [
        'price'    => 'float',
        'stock'    => 'integer',
        'tags'     => 'json',
        'attrs'    => 'json',
        'on_sale'  => 'bool',
    ];

    // JSON 字段（数组 <-> JSON 字符串）
    protected $json = ['tags', 'attrs'];
    protected $jsonAssoc = true;

    protected $autoWriteTimestamp = true;
    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    // —— 获取器：实际折扣价（会员价）——
    public function getFinalPriceAttr($value, array $data): float
    {
        $price = (float)($data['price'] ?? 0);
        $rate  = (float)($data['discount'] ?? 1.0);
        return round($price * $rate, 2);
    }

    // —— 修改器：名称入库前规范化 ——
    public function setNameAttr($value): string
    {
        return trim((string)$value);
    }

    // —— 搜索器：作用域查询 ——
    public function searchNameAttr($query, $value, array $data)
    {
        $query->where('name', 'like', '%' . $value . '%');
    }

    public function scopeOnSale($query)
    {
        return $query->where('on_sale', 1);
    }

    // —— 关联：一个商品多条订单项 ——
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class, 'product_id', 'id');
    }

    // —— 关联：一个商品多条评价 ——
    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class, 'product_id', 'id');
    }

    // —— 业务方法：库存扣减（乐观锁思路演示）——
    public static function deductStock(int $productId, int $qty): bool
    {
        $m = static::findOrEmpty($productId);
        if ($m->isEmpty() || !$m->on_sale) {
            return false;
        }
        if ($m->stock < $qty) {
            return false;
        }
        $m->stock -= $qty;
        $m->save();
        return true;
    }
}
