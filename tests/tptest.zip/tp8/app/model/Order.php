<?php
declare(strict_types=1);

namespace app\model;

use think\Model;
use think\model\relation\BelongsTo;

/**
 * 订单模型
 */
class Order extends Model
{
    protected $table = 'orders';
    protected $autoWriteTimestamp = true;

    protected $type = [
        'total'  => 'float',
        'status' => 'integer',
    ];

    public const STATUS_PENDING = 0;
    public const STATUS_PAID    = 1;
    public const STATUS_CLOSED  = 9;

    // —— 关联：订单属于用户 ——
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    // —— 关联：订单多条订单项 ——
    public function items()
    {
        return $this->hasMany(OrderItem::class, 'order_id', 'id');
    }

    // —— 状态文本获取器 ——
    public function getStatusTextAttr($value, array $data): string
    {
        return match ((int)($data['status'] ?? -1)) {
            self::STATUS_PENDING => '待支付',
            self::STATUS_PAID    => '已支付',
            self::STATUS_CLOSED  => '已关闭',
            default              => '未知',
        };
    }
}
