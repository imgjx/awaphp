<?php
declare(strict_types=1);

namespace app\model;

use think\Model;

class User extends Model
{
    protected $table = 'users';
    protected $autoWriteTimestamp = true;

    public function orders()
    {
        return $this->hasMany(Order::class, 'user_id', 'id');
    }
}
