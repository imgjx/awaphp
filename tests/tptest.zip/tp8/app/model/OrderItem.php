<?php
declare(strict_types=1);

namespace app\model;

use think\Model;

class OrderItem extends Model
{
    protected $table = 'order_items';
    protected $autoWriteTimestamp = false;

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id', 'id');
    }
}
