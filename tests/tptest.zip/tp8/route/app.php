<?php
// 路由定义
use think\facade\Route;

Route::get('shop/seed', 'Shop/seed');
Route::get('shop/products', 'Shop/products');
Route::post('shop/place', 'Shop/place');
Route::get('shop/order/:id', 'Shop/order');
Route::get('shop/calc', 'Shop/calc');
Route::get('shop/search', 'Shop/search');
Route::get('shop/review-stats', 'Shop/reviewStats');
Route::get('think', function () {
    return 'hello,ThinkPHP8!';
});
